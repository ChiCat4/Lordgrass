using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(PolygonCollider2D))]
public class HexTile : MonoBehaviour
{
    public const int NeutralOwnerId = -1;

    [Header("���������")]
    [SerializeField] private Color selectedColor = Color.yellow;

    private SpriteRenderer spriteRenderer;
    private Color normalColor;
    private HexGridGenerator grid;

    public int Q { get; private set; }
    public int R { get; private set; }
    public int OwnerId { get; private set; } = NeutralOwnerId;

    public Unit UnitOnTile { get; private set; }
    public Building BuildingOnTile { get; private set; }

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        normalColor = spriteRenderer.color;
    }

    public void Initialize(int q, int r, HexGridGenerator owningGrid)
    {
        Q = q;
        R = r;
        grid = owningGrid;
        gameObject.name = $"����� ({Q}, {R})";
    }

    public void SetOwner(int ownerId)
    {
        OwnerId = ownerId;
    }

    public bool TryPlaceUnit(Unit unit)
    {
        if (unit == null || UnitOnTile != null)
        {
            return false;
        }

        UnitOnTile = unit;
        unit.SetCurrentTile(this);
        return true;
    }

    public void RemoveUnit(Unit unit)
    {
        if (UnitOnTile != unit)
        {
            return;
        }

        UnitOnTile = null;
        unit.SetCurrentTile(null);
    }

    public bool TryPlaceBuilding(Building building)
    {
        if (building == null || BuildingOnTile != null)
        {
            return false;
        }

        BuildingOnTile = building;
        building.SetCurrentTile(this);
        return true;
    }

    public void RemoveBuilding(Building building)
    {
        if (BuildingOnTile != building)
        {
            return;
        }

        BuildingOnTile = null;
        building.SetCurrentTile(null);
    }

    public void SetSelected(bool isSelected)
    {
        if (spriteRenderer == null)
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
        }

        spriteRenderer.color = isSelected ? selectedColor : normalColor;
    }

    private void OnMouseDown()
    {
        if (grid != null)
        {
            grid.SelectTile(this);
        }
    }
}