using UnityEngine;

[CreateAssetMenu(
    fileName = "New Building",
    menuName = "Lordgrass/Building Definition"
)]
public class BuildingDefinition : ScriptableObject
{
    [SerializeField] private string displayName;

    [Min(0)]
    [SerializeField] private int defenseLevel;

    public string DisplayName => displayName;
    public int DefenseLevel => defenseLevel;
}