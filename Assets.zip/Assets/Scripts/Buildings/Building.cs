using UnityEngine;

public class Building : MonoBehaviour
{
    [SerializeField] private BuildingDefinition definition;

    public BuildingDefinition Definition => definition;
    public int OwnerId { get; private set; }
    public HexTile CurrentTile { get; private set; }

    public void Initialize(int ownerId, HexTile startingTile)
    {
        OwnerId = ownerId;
        SetCurrentTile(startingTile);

        if (definition == null)
        {
            Debug.LogError($"� ������ {name} �� �������� Building Definition.");
        }
    }

    public void SetCurrentTile(HexTile newTile)
    {
        CurrentTile = newTile;
    }
}