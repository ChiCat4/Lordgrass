using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Camera))]
public class CameraZoomPan2D : MonoBehaviour
{
    [Header("�������")]
    [SerializeField] private float minZoom = 2f;
    [SerializeField] private float maxZoom = 10f;
    [SerializeField] private float mouseZoomSpeed = 0.5f;
    [SerializeField] private float pinchZoomSpeed = 0.01f;

    private Camera cam;

    private Vector2 previousMousePosition;
    private bool isMousePanning;

    private int previousTouchCount;
    private Vector2 previousTouchPosition1;
    private Vector2 previousTouchPosition2;

    private void Awake()
    {
        cam = GetComponent<Camera>();

        if (!cam.orthographic)
        {
            Debug.LogWarning("CameraZoomPan2D ��������� �� ��������������� ������.");
        }
    }

    private void Update()
    {
        if (cam == null || !cam.orthographic)
            return;

        if (HandleTouchInput())
        {
            isMousePanning = false;
            return;
        }

        HandleMouseInput();
    }

    private bool HandleTouchInput()
    {
        if (Touchscreen.current == null)
        {
            previousTouchCount = 0;
            return false;
        }

        var touches = Touchscreen.current.touches;
        int touchCount = 0;
        Vector2 position1 = Vector2.zero;
        Vector2 position2 = Vector2.zero;

        foreach (var touch in touches)
        {
            if (!touch.press.isPressed)
                continue;

            if (touchCount == 0)
                position1 = touch.position.ReadValue();
            else if (touchCount == 1)
                position2 = touch.position.ReadValue();

            touchCount++;
            if (touchCount == 2)
                break;
        }

        if (touchCount == 0)
        {
            previousTouchCount = 0;
            return false;
        }

        float unitsPerPixel = (cam.orthographicSize * 2f) / Screen.height;

        if (touchCount == 1)
        {
            if (previousTouchCount == 1)
            {
                Vector2 delta = position1 - previousTouchPosition1;
                PanCamera(delta, unitsPerPixel);
            }

            previousTouchPosition1 = position1;
        }
        else
        {
            if (previousTouchCount == 2)
            {
                float previousDistance =
                    Vector2.Distance(previousTouchPosition1, previousTouchPosition2);
                float currentDistance = Vector2.Distance(position1, position2);
                float pinchDelta = currentDistance - previousDistance;

                cam.orthographicSize = Mathf.Clamp(
                    cam.orthographicSize - pinchDelta * pinchZoomSpeed,
                    minZoom,
                    maxZoom
                );
            }

            previousTouchPosition1 = position1;
            previousTouchPosition2 = position2;
        }

        previousTouchCount = touchCount;
        return true;
    }

    private void HandleMouseInput()
    {
        if (Mouse.current == null)
            return;

        float scroll = Mouse.current.scroll.ReadValue().y;

        if (scroll != 0f)
        {
            // �� ��������� ����� ��������� �������� ������ �� 120, �� ������ � �� 1.
            float scrollAmount = Mathf.Abs(scroll) > 10f ? scroll / 120f : scroll;

            cam.orthographicSize = Mathf.Clamp(
                cam.orthographicSize - scrollAmount * mouseZoomSpeed,
                minZoom,
                maxZoom
            );
        }

        Vector2 mousePosition = Mouse.current.position.ReadValue();

        if (Mouse.current.rightButton.isPressed)
        {
            if (isMousePanning)
            {
                Vector2 delta = mousePosition - previousMousePosition;
                float unitsPerPixel = (cam.orthographicSize * 2f) / Screen.height;
                PanCamera(delta, unitsPerPixel);
            }

            previousMousePosition = mousePosition;
            isMousePanning = true;
        }
        else
        {
            isMousePanning = false;
        }
    }

    private void PanCamera(Vector2 screenDelta, float unitsPerPixel)
    {
        transform.position -= new Vector3(
            screenDelta.x * unitsPerPixel,
            screenDelta.y * unitsPerPixel,
            0f
        );
    }
}