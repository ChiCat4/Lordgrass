using UnityEngine;

public class TurnManager : MonoBehaviour
{
    [SerializeField] private int currentPlayer = 1;

    public int CurrentPlayer => currentPlayer;

    public void NextTurn()
    {
        currentPlayer++;

        if (currentPlayer > 2)
        {
            currentPlayer = 1;
        }
    }
}