using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(PolygonCollider2D))]
public class HexTile : MonoBehaviour
{
    public const int NeutralOwnerId = -1;

    [Header("���������")]
    [SerializeField] private Color selectedColor = Color.yellow;

    private SpriteRenderer spriteRenderer;
    private Color normalColor;
    private bool isSelected;
    private bool isDimmed;
    private HexGridGenerator grid;
    [SerializeField, Range(0f, 1f)]
    private float territoryOverlayAlpha = 0.25f;

    [SerializeField, Min(0.001f)]
    private float territoryBorderWidth = 0.035f;

    private PolygonCollider2D polygonCollider;
    private SpriteRenderer territoryOverlay;
    private LineRenderer[] territoryBorders;

    public int Q { get; private set; }
    public int R { get; private set; }
    public int OwnerId { get; private set; } = NeutralOwnerId;

    public Unit UnitOnTile { get; private set; }
    public Building BuildingOnTile { get; private set; }

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        normalColor = spriteRenderer.color;
        polygonCollider = GetComponent<PolygonCollider2D>();

        CreateTerritoryVisuals();
    }


    public void Initialize(int q, int r, HexGridGenerator owningGrid)
    {
        Q = q;
        R = r;
        grid = owningGrid;
        gameObject.name = $"����� ({Q}, {R})";
    }

    public void SetOwner(int ownerId)
    {
        OwnerId = ownerId;

        if (grid != null)
        {
            grid.RefreshTerritoryVisuals();
        }
        else
        {
            RefreshTerritoryVisuals();
        }
    }

    public bool TryPlaceUnit(Unit unit)
    {
        if (unit == null || UnitOnTile != null)
        {
            return false;
        }

        UnitOnTile = unit;
        unit.SetCurrentTile(this);
        return true;
    }

    public void RemoveUnit(Unit unit)
    {
        if (UnitOnTile != unit)
        {
            return;
        }

        UnitOnTile = null;
        unit.SetCurrentTile(null);
    }

    public bool TryPlaceBuilding(Building building)
    {
        if (building == null || BuildingOnTile != null)
        {
            return false;
        }

        BuildingOnTile = building;
        building.SetCurrentTile(this);
        return true;
    }

    public void RemoveBuilding(Building building)
    {
        if (BuildingOnTile != building)
        {
            return;
        }

        BuildingOnTile = null;
        building.SetCurrentTile(null);
    }

    private void CreateTerritoryVisuals()
    {
        GameObject overlayObject = new GameObject("Territory Overlay");
        overlayObject.transform.SetParent(transform, false);

        territoryOverlay = overlayObject.AddComponent<SpriteRenderer>();
        territoryOverlay.sprite = spriteRenderer.sprite;
        territoryOverlay.sortingLayerID = spriteRenderer.sortingLayerID;
        territoryOverlay.sortingOrder = spriteRenderer.sortingOrder + 1;
        territoryOverlay.color = new Color(1f, 1f, 1f, territoryOverlayAlpha);
        territoryOverlay.enabled = false;

        Vector2[] points = polygonCollider.points;
        territoryBorders = new LineRenderer[points.Length];

        for (int i = 0; i < territoryBorders.Length; i++)
        {
            GameObject borderObject = new GameObject($"Territory Border {i}");
            borderObject.transform.SetParent(transform, false);

            LineRenderer line = borderObject.AddComponent<LineRenderer>();
            line.useWorldSpace = true;
            line.positionCount = 2;
            line.startWidth = territoryBorderWidth;
            line.endWidth = territoryBorderWidth;
            line.startColor = Color.white;
            line.endColor = Color.white;
            line.numCapVertices = 0;
            line.sortingLayerID = spriteRenderer.sortingLayerID;
            line.sortingOrder = spriteRenderer.sortingOrder + 2;
            line.sharedMaterial = spriteRenderer.sharedMaterial;
            line.enabled = false;

            territoryBorders[i] = line;
        }
    }

    public void RefreshTerritoryVisuals()
    {
        if (territoryOverlay == null || polygonCollider == null)
        {
            return;
        }

        bool isOwned = OwnerId != NeutralOwnerId;

        territoryOverlay.sprite = spriteRenderer.sprite;
        territoryOverlay.color = new Color(1f, 1f, 1f, territoryOverlayAlpha);
        territoryOverlay.enabled = isOwned;

        foreach (LineRenderer line in territoryBorders)
        {
            line.enabled = false;
        }

        if (!isOwned || grid == null)
        {
            return;
        }

        List<HexTile> neighbors = grid.GetNeighbors(this);
        Vector2[] points = polygonCollider.points;
        Vector3 center = transform.TransformPoint(polygonCollider.offset);

        for (int i = 0; i < points.Length; i++)
        {
            Vector3 pointA = transform.TransformPoint(points[i]);
            Vector3 pointB = transform.TransformPoint(points[(i + 1) % points.Length]);
            Vector3 midpoint = (pointA + pointB) * 0.5f;

            Vector2 outward = ((Vector2)(midpoint - center)).normalized;

            HexTile closestNeighbor = null;
            float bestAlignment = -1f;

            foreach (HexTile neighbor in neighbors)
            {
                Vector2 direction =
                    ((Vector2)(neighbor.transform.position - transform.position)).normalized;

                float alignment = Vector2.Dot(outward, direction);

                if (alignment > bestAlignment)
                {
                    bestAlignment = alignment;
                    closestNeighbor = neighbor;
                }
            }

            // ���� ������� ���� ������� ����� ���� ������,
            // ���������� ������� �� ������.
            bool isTerritoryEdge =
                closestNeighbor == null ||
                bestAlignment < 0.85f ||
                closestNeighbor.OwnerId != OwnerId;

            if (!isTerritoryEdge)
            {
                continue;
            }

            LineRenderer line = territoryBorders[i];
            line.SetPosition(0, pointA);
            line.SetPosition(1, pointB);
            line.enabled = true;
        }
    }

    public void SetSelected(bool isSelected)
    {
        this.isSelected = isSelected;
        ApplyTileColor();
    }

    public void SetDimmed(bool isDimmed)
    {
        this.isDimmed = isDimmed;
        ApplyTileColor();
    }

    private void ApplyTileColor()
    {
        if (spriteRenderer == null)
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
        }

        if (isSelected)
        {
            spriteRenderer.color = Color.white;
        }
        else if (isDimmed)
        {
            spriteRenderer.color = new Color(0.3f, 0.3f, 0.3f, normalColor.a);
        }
        else
        {
            spriteRenderer.color = normalColor;
        }
    }

    private void OnMouseDown()
    {
        if (grid != null)
        {
            grid.SelectTile(this);
        }
    }
}