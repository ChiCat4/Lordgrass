using UnityEngine;

public class Unit : MonoBehaviour
{
    [SerializeField] private UnitDefinition definition;

    public UnitDefinition Definition => definition;
    public int OwnerId { get; private set; }
    public HexTile CurrentTile { get; private set; }
    public bool HasUsedAction { get; private set; }

    public void Initialize(
        UnitDefinition unitDefinition,
        int ownerId,
        HexTile startingTile)
    {
        definition = unitDefinition;
        OwnerId = ownerId;
        SetCurrentTile(startingTile);
        HasUsedAction = false;

        if (definition == null)
        {
            Debug.LogError($"� ����� {name} �� �������� Unit Definition.");
            return;
        }

        gameObject.name = definition.DisplayName;
    }

    public void SetCurrentTile(HexTile newTile)
    {
        CurrentTile = newTile;

        if (newTile != null)
        {
            transform.position = newTile.transform.position;
        }
    }

    public bool TryUseAction()
    {
        if (HasUsedAction)
        {
            return false;
        }

        HasUsedAction = true;
        return true;
    }

    public void ResetAction()
    {
        HasUsedAction = false;
    }
}