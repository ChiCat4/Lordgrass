using UnityEngine;

public class Unit : MonoBehaviour
{
    [SerializeField] private UnitDefinition definition;

    public UnitDefinition Definition => definition;
    public int OwnerId { get; private set; }
    public HexTile CurrentTile { get; private set; }
    public bool HasUsedAction { get; private set; }

    public void Initialize(UnitDefinition unitDefinition, int ownerId, HexTile startingTile)
    {
        definition = unitDefinition;
        OwnerId = ownerId;
        CurrentTile = startingTile;
        HasUsedAction = false;
    }

    public void SetCurrentTile(HexTile newTile)
    {
        CurrentTile = newTile;
    }

    public void MoveToTile(HexTile tile)
    {
        CurrentTile = tile;
    }

    public bool TryUseAction()
    {
        if (HasUsedAction)
            return false;

        HasUsedAction = true;
        return true;
    }

    public void ResetAction()
    {
        HasUsedAction = false;
    }
}