using UnityEngine;

public class Unit : MonoBehaviour
{
    [SerializeField] private UnitDefinition definition;

    public UnitDefinition Definition => definition;
    public int OwnerId { get; private set; }
    public HexTile CurrentTile { get; private set; }
    public bool HasUsedAction { get; private set; }

    public void Initialize(UnitDefinition unitDefinition, int ownerId, HexTile startingTile)
    {
        definition = unitDefinition;
        OwnerId = ownerId;
        CurrentTile = startingTile;
        HasUsedAction = false;
    }

    public void SetCurrentTile(HexTile newTile)
    {
        CurrentTile = newTile;
    }

    public bool MoveToTile(HexTile tile)
    {
        if (tile == null || CurrentTile == null)
        {
            return false;
        }

        if (tile == CurrentTile || tile.UnitOnTile != null)
        {
            return false;
        }

        HexTile previousTile = CurrentTile;
        previousTile.RemoveUnit(this);

        if (!tile.TryPlaceUnit(this))
        {
            previousTile.TryPlaceUnit(this);
            return false;
        }

        transform.position = tile.transform.position;
        return true;
    }

    public bool TryUseAction()
    {
        if (HasUsedAction)
            return false;

        HasUsedAction = true;
        return true;
    }

    public void ResetAction()
    {
        HasUsedAction = false;
    }
    public bool IsOnFriendlyLand()
    {
        return CurrentTile != null &&
               CurrentTile.OwnerId == OwnerId;
    }

    public int GetStepRange(HexTile startingTile)
    {
        if (startingTile == null)
            return 0;

        return startingTile.OwnerId == OwnerId
            ? Definition.StepRangeOnFriendlyLand + 4
            : Definition.StepRangeToCapture;
    }
}
