using UnityEngine;

public enum UnitType
{
    Peasant,
    Warrior,
    Archer,
    Cavalry,
    Armored,
    Crossbowman,
    MountedArmored
}

[CreateAssetMenu(
    fileName = "New Unit",
    menuName = "Lordgrass/Unit Definition"
)]
public class UnitDefinition : ScriptableObject
{
    [Header("���")]
    [SerializeField] private UnitType unitType;
    [SerializeField] private string displayName;

    [Header("��������������")]
    [Min(0)]
    [SerializeField] private int attackLevel;

    [Min(0)]
    [SerializeField] private int defenseLevel;

    [Min(0)]
    [SerializeField] private int stepRangeOnFriendlyLand = 2;

    [Min(0)]
    [SerializeField] private int stepRangeToCapture = 1;

    [Min(0)]
    [SerializeField] private int attackRange = 1;

    public UnitType Type => unitType;
    public string DisplayName => displayName;
    public int AttackLevel => attackLevel;
    public int DefenseLevel => defenseLevel;
    public int StepRangeOnFriendlyLand => stepRangeOnFriendlyLand;
    public int StepRangeToCapture => stepRangeToCapture;
    public int AttackRange => attackRange;
}