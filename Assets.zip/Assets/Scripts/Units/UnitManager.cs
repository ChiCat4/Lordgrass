using System.Collections.Generic;
using UnityEngine;

public class UnitManager : MonoBehaviour
{
    [SerializeField] private HexGridGenerator gridGenerator;
    [SerializeField] private GameObject unitPrefab;

    private readonly List<Unit> units = new List<Unit>();

    private void Start()
    {
        if (gridGenerator == null)
        {
            gridGenerator = FindObjectOfType<HexGridGenerator>();
        }
    }

    public void SpawnUnit(UnitDefinition unitDefinition, HexTile tile, int ownerId)
    {
        if (unitDefinition == null)
        {
            Debug.LogWarning("�� �������� UnitDefinition.");
            return;
        }

        if (tile == null)
        {
            Debug.LogWarning("Tile �� ������.");
            return;
        }

        if (tile.UnitOnTile != null)
        {
            Debug.LogWarning("�� ������ ��� ���� ����.");
            return;
        }

        GameObject instance = Instantiate(unitPrefab, transform);
        Unit unit = instance.GetComponent<Unit>();

        if (unit == null)
        {
            unit = instance.AddComponent<Unit>();
        }

        unit.Initialize(unitDefinition, ownerId, tile);
        tile.SetUnit(unit);

        units.Add(unit);
    }

    public bool TryMoveUnit(Unit unit, HexTile targetTile)
    {
        if (unit == null || targetTile == null)
        {
            return false;
        }

        if (unit.HasUsedAction)
        {
            return false;
        }

        if (unit.CurrentTile == null)
        {
            return false;
        }

        if (!IsAdjacent(unit.CurrentTile, targetTile))
        {
            return false;
        }

        if (targetTile.UnitOnTile != null)
        {
            return false;
        }

        unit.CurrentTile.RemoveUnit();
        targetTile.SetUnit(unit);
        unit.MoveToTile(targetTile);
        unit.MarkActionUsed();

        return true;
    }

    private bool IsAdjacent(HexTile from, HexTile to)
    {
        if (gridGenerator == null)
        {
            return false;
        }

        List<HexTile> neighbors = gridGenerator.GetNeighbors(from);

        foreach (HexTile tile in neighbors)
        {
            if (tile == to)
            {
                return true;
            }
        }

        return false;
    }
}